package com.test;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("triangle1")
public class Triangle {

	@Value("Equilateral")
	private String triangleName;
	
	private Point point;

	public Triangle() {
		super();
	}
	@Autowired
	public Triangle(Point point) {
		super();
		this.point = point;
		System.out.println("constructor injection");
	}

	public String getTriangleName() {
		return triangleName;
	}

	public void setTriangleName(String triangleName) {
		this.triangleName = triangleName;
	}

	public Point getPoint() {
		return point;
	}
	
	public void setPoint(Point point) {
		this.point = point;
		System.out.println("setter injection");
	}

	@PostConstruct
	public void init() {
		System.out.println("init called");
	}

	public void draw() {
		System.out.println("Triangle draw  " + triangleName + "\n"
				+ point.getX() + "\n" + point.getY());
	}

	@PreDestroy
	public void destroy() {
		System.out.println("destroy called");
	}

}
