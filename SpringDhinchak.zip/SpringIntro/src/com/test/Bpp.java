package com.test;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;

public class Bpp implements BeanPostProcessor {

	@Override
	public Object postProcessAfterInitialization(Object obj, String name)
			throws BeansException {
          System.out.println("BPP AFTER INIT CALLED");
		return obj;
	}

	@Override
	public Object postProcessBeforeInitialization(Object obj, String name)
			throws BeansException {
		System.out.println("BPP BEFORE INIT CALLED");
		return obj;
	}

}
