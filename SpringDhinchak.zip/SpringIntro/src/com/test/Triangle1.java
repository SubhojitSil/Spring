package com.test;

import java.util.List;

public class Triangle1 {
   
	private Point point;
	
private List<Point> points;
	public Triangle1() {
		super();
	}


	public Triangle1(Point point) {
		super();
		this.point = point;
		System.err.println("By constructor");
	}


	public Point getPoint() {
		return point;
	}


	public void setPoint(Point point) {
		this.point = point;
		System.err.println("by setter");
	}


	public List<Point> getPoints() {
		return points;
	}


	public void setPoints(List<Point> points) {
		this.points = points;
	}


	public void draw()
	 {
		 System.out.println("Triangle draw");
		 for(Point p:points){
			 System.out.println(p.getX()+" "+p.getY());
		 }
		
	 }


}
