package com.test;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestAppp {
	public static void main(String[] args) {
		
		ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("spring2.xml"); 
		
		Triangle1 obj1 = (Triangle1)ctx.getBean("triangle");
		
		obj1.draw();
		ctx.close();
		
		/*Triangle t = new Triangle();
		Point p = new Point();
		p.setX(10);
		p.setY(20);*/
		
		
	}
}
