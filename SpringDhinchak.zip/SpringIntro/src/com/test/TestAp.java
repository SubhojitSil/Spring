package com.test;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestAp {
	public static void main(String[] args) {

		ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext(
				"spring3.xml");

		Triangle obj1 = (Triangle) ctx.getBean("triangle1");

		obj1.draw();

		ctx.close();
	}
}
