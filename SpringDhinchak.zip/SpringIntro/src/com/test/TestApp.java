package com.test;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestApp {
public static void main(String[] args) {
	
	ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("spring3.xml"); 
	
	Triangle obj1 = (Triangle)ctx.getBean("triangle");
	//obj.setName("Equilateral");
	
	obj1.draw();
	
	/*Triangle obj2 = (Triangle)ctx.getBean("triangle");
	
	obj2.draw();
	
	if(obj1==obj2)
	{
		System.out.println("Singleton");
	}
	else
	{
		System.out.println("prototype");
	}*/
	
	ctx.close();
}
}
